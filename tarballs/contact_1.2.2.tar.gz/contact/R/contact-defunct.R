#' Defunct functions in contact
#' 
#' These functions have been removed from our package.
#' 
#' \itemize{
#'  \item \code{\link{contactTest}}: contactTest is defunct and was removed 
#'  in version 1.2.0. Please consider using another contact-comparison function
#'  instead (e.g., contactCompare_chisq, contactCompare_mantel, etc.)"
#' }
#' 
#' @name contact-defunct
NULL